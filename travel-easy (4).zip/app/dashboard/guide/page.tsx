export default function GuideDashboard() {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Tour Guide Dashboard</h2>
      <p>Welcome to your guide dashboard. Manage your tours, bookings, and reviews here.</p>
      {/* Add guide-specific dashboard content here */}
    </div>
  )
}

