export default function UserDashboard() {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">User Dashboard</h2>
      <p>Welcome to your dashboard. View your trips, bookings, and share your travel experiences here.</p>
      {/* Add user-specific dashboard content here */}
    </div>
  )
}

